#print("Lavanya".count('L'))
print("Welcome to Love Calculator")
name1 = input("Enter your Name: ")
name2 = input("Enter your Lover Name: ")
lower_name1 = name1.lower()
lower_name2 = name2.lower()

newname = lower_name1+lower_name2
cnt1 = newname.count('t')
cnt2 = newname.count('r')
cnt3 = newname.count('u')
cnt4 = newname.count('e')
cnt5 = newname.count('l')
cnt6 = newname.count('o')
cnt7 = newname.count('v')
cnt8 = newname.count('e')
score1 = cnt1 + cnt2 + cnt3 + cnt4
score2 = cnt5 + cnt6 + cnt7 + cnt8

Love_Score = int(str(score1) + str(score2))


if (Love_Score <10) or (Love_Score>90):
  print(f"Your Score is {Love_Score},you go together like coke and mentos.")
elif (Love_Score <=50) and (Love_Score>=40):
  print(f"Your Score is {Love_Score},you are alright together.")
else:
  print("Your score is ",Love_Score)
