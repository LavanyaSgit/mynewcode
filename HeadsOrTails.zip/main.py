# Solution
#[https://repl.it/@appbrewery/day-4-1-solution]#(https://repl.it/@appbrewery/day-4-1-solution)
import random
choice =input("Choose your choice (Heads/Tails): \n").lower()
if choice == "heads":
  ch=1
elif choice == "tails":
  ch=0
else:
  print("Please choose a correct choice! \n")
rd = random.randint(0,1)
if rd==1:
  print("Toss came as Heads \n")
else:
  print("Toss came as Tails \n")
if ch == rd:
  print("You Won!!!")
else:
  print("You Lose!!!")
